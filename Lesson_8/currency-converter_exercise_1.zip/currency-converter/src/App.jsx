import './App.css'

import { useState } from 'react' 

import CurrencyDropdown from './CurrencyDropdown';

function App() {
  // variable
  // let count = 0

  const handleOnClick = () => {
    // count += 1

    setCount(count + 1)
    console.log('handleOnClick executed successfully. Count is ', count)
  }


  const [count, setCount] = useState(0)

  return (
    <>
      <h1>Currency Converter</h1>
      {/* <CurrencyDropdown /> */}
      <button onClick={handleOnClick}>Increment</button>
      <p>{count}</p>
    </>
  )
}



export default App;
