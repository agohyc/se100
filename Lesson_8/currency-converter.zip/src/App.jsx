import './App.css'

function App() {

  return (
    <>
      <h1>Currency Converter</h1>
      <button>
        Click me
      </button>
    </>
  )
}

export default App;
