import './CurrencyConverter.css'

const CurrencyConverter = () => {
    return (
        <div className="container">
            {/* Problem 2: conversion rate is hardcoded right now */}
            {/* Problem 3: user cannot type in input box */}
            <input
                value={1}
                placeholder="Enter amount"
                className="converter-input"
                onChange={() => { }}
            />
            {/* Problem 1: the user selected option doesn't update here */}
            <p>EUR</p>
            <p>=</p>
            <p>2</p>
            <p>USD</p>
        </div>
    )
}

export default CurrencyConverter